@echo off
setlocal EnableExtensions

set "TARGET_ROOT=%APPDATA%\Adobe\CEP\extensions"

echo.
echo ================================================
echo  Uninstall Bezier Inspector - Windows
echo ================================================
echo.

tasklist /FI "IMAGENAME eq Illustrator.exe" 2>nul | find /I "Illustrator.exe" >nul
if "%ERRORLEVEL%"=="0" (
  echo Please quit Illustrator completely first.
  echo.
  pause
  exit /b 1
)

if exist "%TARGET_ROOT%\com.ju.bezierinspector" rmdir /S /Q "%TARGET_ROOT%\com.ju.bezierinspector"
if exist "%TARGET_ROOT%\com.ju.bezierInspector" rmdir /S /Q "%TARGET_ROOT%\com.ju.bezierInspector"
if exist "%TARGET_ROOT%\Bezier Inspector" rmdir /S /Q "%TARGET_ROOT%\Bezier Inspector"

if exist "%LOCALAPPDATA%\Adobe\CEP\cep_cache" rmdir /S /Q "%LOCALAPPDATA%\Adobe\CEP\cep_cache"

echo Uninstalled.
echo.
pause
exit /b 0
