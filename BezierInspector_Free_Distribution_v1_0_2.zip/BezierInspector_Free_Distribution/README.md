# 🟠 Bézier Inspector v1.0.4
# 🟠 Bézier Inspector v1.0.4

Bézier Inspector is a CEP extension for Adobe Illustrator that visualizes Bézier geometry directly on the artboard.  
Bézier Inspector는 Adobe Illustrator에서 선택한 벡터/텍스트의 Bézier 구조를 아트보드 위에 직접 표시해주는 CEP 확장입니다.

---

## ✨ Features / 기능

- Anchor points / 앵커 포인트
- Bézier handles / Bézier 핸들
- Handle connector lines / 핸들 연결선
- Baseline / 베이스라인
- x-height / x-height
- Cap height / Cap height
- Ascent / 어센트
- Descent / 디센트
- Live overlay layer inside Illustrator / Illustrator 내부 라이브 오버레이 레이어

---

## ⚠️ Important / 중요

Do **not** use the same installer command for macOS and Windows.  
macOS와 Windows는 설치 명령이 다릅니다.

```text
macOS:   bash install.sh
Windows: install_windows.bat
```

If a Windows user runs `install.sh`, they may see errors such as:  
Windows 사용자가 `install.sh`를 실행하면 아래와 같은 오류가 날 수 있습니다.

```text
defaults: command not found
```

That is expected because `defaults` is a macOS-only command.  
`defaults`는 macOS 전용 명령어이므로 Windows에서는 정상적으로 존재하지 않습니다.

---

## 📌 Stable file name / 고정 파일명

The distribution ZIP uses a stable file name so the GitHub release download link can stay the same across updates.  
배포 ZIP 파일명은 업데이트 후에도 다운로드 링크가 유지되도록 고정합니다.

```text
BezierInspector_Free_Distribution.zip
```

The actual version is written inside `VERSION.txt`.  
실제 버전 정보는 `VERSION.txt` 안에 기록되어 있습니다.

---

## 📦 Download / 다운로드

Download this ZIP from GitHub Releases → Assets.  
GitHub Releases → Assets에서 아래 ZIP 파일을 다운로드하세요.

```text
BezierInspector_Free_Distribution.zip
```

Do **not** use the green `Code → Download ZIP` button unless the repository root contains the installer files directly.  
초록색 `Code → Download ZIP` 버튼은 권장하지 않습니다. Releases → Assets의 ZIP을 다운로드하세요.

---

# ✅ macOS Installation / macOS 설치

## 1. Quit Illustrator / Illustrator 종료

Quit Adobe Illustrator completely before installing.  
설치 전에 Adobe Illustrator를 완전히 종료하세요.

## 2. Unzip the file / ZIP 압축 해제

Unzip the downloaded file.  
다운로드한 ZIP 파일의 압축을 풉니다.

## 3. Open Terminal / Terminal 열기

Open Terminal and move to the unzipped folder.  
Terminal을 열고 압축을 푼 폴더로 이동합니다.

Example / 예시:

```bash
cd ~/Downloads/BezierInspector_Free_Distribution
```

## 4. Run installer / 설치 실행

```bash
bash install.sh
```

## 5. Restart Illustrator / Illustrator 재시작

Restart Illustrator, then open:  
Illustrator를 다시 실행한 뒤 아래 메뉴에서 여세요.

```text
Illustrator 2022:
Window → Extensions → Bézier Inspector

Illustrator 2023–2026:
Window → Extensions (Legacy) → Bézier Inspector

Korean UI:
창 → 확장 기능 또는 확장 기능(레거시) → Bézier Inspector
```

---

# ✅ Windows 11 Installation / Windows 11 설치

## 1. Quit Illustrator / Illustrator 종료

Quit Adobe Illustrator completely before installing.  
설치 전에 Adobe Illustrator를 완전히 종료하세요.

## 2. Unzip the file / ZIP 압축 해제

Unzip the downloaded file.  
다운로드한 ZIP 파일의 압축을 풉니다.

## 3. Run Windows installer / Windows 설치 파일 실행

Double-click:  
아래 파일을 더블클릭하세요.

```text
install_windows.bat
```

Do **not** run it as Administrator.  
관리자 권한으로 실행하지 마세요. 현재 Illustrator를 사용하는 일반 사용자 계정으로 실행해야 합니다.

The installer will copy the extension to:  
설치 파일은 확장을 아래 위치로 복사합니다.

```text
%APPDATA%\Adobe\CEP\extensions\com.ju.bezierinspector
```

It will also enable PlayerDebugMode in the Windows registry.  
또한 Windows 레지스트리에 CEP PlayerDebugMode를 설정합니다.

## 4. Restart Illustrator / Illustrator 재시작

Restart Illustrator, then open:  
Illustrator를 다시 실행한 뒤 아래 메뉴에서 여세요.

```text
Illustrator 2022:
Window → Extensions → Bézier Inspector

Illustrator 2023–2026:
Window → Extensions (Legacy) → Bézier Inspector

Korean UI:
창 → 확장 기능 또는 확장 기능(레거시) → Bézier Inspector
```

---

# 🩶 Gray Panel Fix / 회색 패널 복구

If the panel opens as a blank gray window, run the repair script for your OS.  
패널이 빈 회색 화면으로 뜨면 사용하는 OS에 맞는 복구 스크립트를 실행하세요.

## macOS

Quit Illustrator, then run:  
Illustrator를 종료한 뒤 실행:

```bash
bash repair.sh
```

## Windows 11

Quit Illustrator, then double-click:  
Illustrator를 종료한 뒤 더블클릭:

```text
repair_windows.bat
```

The repair scripts will:  
복구 스크립트는 아래를 처리합니다.

- Re-enable CEP PlayerDebugMode / CEP PlayerDebugMode 재설정
- Clear CEP cache / CEP 캐시 삭제
- Check duplicate extension folders / 중복 설치 폴더 확인
- macOS only: remove quarantine attributes / macOS: quarantine 속성 제거

Restart Illustrator after repair.  
복구 후 Illustrator를 다시 시작하세요.

---

# 🧪 Diagnostics / 진단 로그

If installation still fails, run the diagnostics script.  
설치 후에도 문제가 있으면 진단 스크립트를 실행하세요.

## macOS

```bash
bash diagnostics.sh
```

## Windows 11

Double-click:  
더블클릭:

```text
diagnostics_windows.bat
```

This creates a diagnostics log on the Desktop.  
Desktop에 진단 로그 파일이 생성됩니다.

---

# 🗑 Uninstall / 제거

## macOS

```bash
bash uninstall.sh
```

## Windows 11

Double-click:  
더블클릭:

```text
uninstall_windows.bat
```

---

# 🧩 ZXP Option / ZXP 옵션

This package includes scripts for creating a self-signed ZXP package.  
이 패키지는 self-signed ZXP를 만들 수 있는 스크립트를 포함합니다.

Adobe `ZXPSignCmd` is not included.  
Adobe `ZXPSignCmd` 실행 파일은 포함되어 있지 않습니다.

Place `ZXPSignCmd` here:  
`ZXPSignCmd`를 아래 위치에 넣으세요.

```text
tools/ZXPSignCmd
```

Then run on macOS or a Unix-like shell:  
그 다음 macOS 또는 Unix-like shell에서 실행:

```bash
chmod +x tools/ZXPSignCmd
bash scripts/build_zxp_self_signed.sh
```

If successful, the ZXP will be created here:  
성공하면 아래 위치에 ZXP 파일이 생성됩니다.

```text
zxp_out/bezier_inspector.zxp
```

You can install the ZXP with ZXPInstaller or Adobe UPIA.  
생성된 ZXP는 ZXPInstaller 또는 Adobe UPIA로 설치할 수 있습니다.

---

# 📁 Included Files / 포함 파일

```text
BezierInspector_Free_Distribution/
├── com.ju.bezierinspector/
├── install.sh
├── repair.sh
├── uninstall.sh
├── diagnostics.sh
├── install_windows.bat
├── repair_windows.bat
├── uninstall_windows.bat
├── diagnostics_windows.bat
├── scripts/
├── tools/
├── zxp_out/
├── zxp_source_com.ju.bezierinspector.zip
├── CHECKSUMS.txt
├── VERSION.txt
└── README.md
```

---

# ⚠️ Notes / 참고

This is a free distribution build.  
이 버전은 무료 배포용 빌드입니다.

It is not a notarized macOS app installer.  
macOS notarized 앱 설치기가 아닙니다.

The previous `.app` installer approach could trigger macOS Gatekeeper warnings unless signed with an Apple Developer ID and notarized.  
기존 `.app` 설치기 방식은 Apple Developer ID로 서명/노타라이즈하지 않으면 macOS Gatekeeper 경고가 뜰 수 있습니다.

For this reason, this build uses script-based installers instead.  
그래서 이번 빌드는 스크립트 기반 설치 방식을 사용합니다.

```text
macOS:   bash install.sh
Windows: install_windows.bat
```
