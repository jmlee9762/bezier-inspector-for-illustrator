#!/bin/bash
set -euo pipefail

export PATH="/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin:/usr/local/bin:${PATH:-}"

if [ "$(/usr/bin/uname -s 2>/dev/null || uname -s)" != "Darwin" ]; then
  echo "ERROR: This uninstall script is for macOS only."
  exit 1
fi

PGREP="/usr/bin/pgrep"
RM="/bin/rm"
DATE="/bin/date"
TEE="/usr/bin/tee"

EXT="$HOME/Library/Application Support/Adobe/CEP/extensions/com.ju.bezierinspector"
LOG="$HOME/Desktop/bezier_inspector_uninstall_$($DATE +%Y%m%d_%H%M%S).log"
exec > >($TEE -a "$LOG") 2>&1

echo "Bézier Inspector uninstaller"
echo "Log: $LOG"
echo ""

if "$PGREP" -x "Adobe Illustrator" >/dev/null 2>&1; then
  echo "ERROR: Please quit Adobe Illustrator before uninstalling."
  exit 1
fi

if [ -d "$EXT" ]; then
  echo "Removing: $EXT"
  "$RM" -rf "$EXT"
else
  echo "Extension folder not found: $EXT"
fi

echo "Clearing CEP cache."
"$RM" -rf "$HOME/Library/Caches/CSXS/cep_cache" 2>/dev/null || true
"$RM" -rf "$HOME/Library/Caches/CSXS/cep_cache_*" 2>/dev/null || true

echo "Uninstall complete."
