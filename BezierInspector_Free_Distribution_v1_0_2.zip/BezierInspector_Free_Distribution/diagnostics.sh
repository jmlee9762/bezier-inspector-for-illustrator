#!/bin/bash
set -euo pipefail

export PATH="/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin:/usr/local/bin:${PATH:-}"

DEFAULTS="/usr/bin/defaults"
FIND="/usr/bin/find"
XATTR="/usr/bin/xattr"
GREP="/usr/bin/grep"
DATE="/bin/date"
TEE="/usr/bin/tee"
UNAME="/usr/bin/uname"
SW_VERS="/usr/bin/sw_vers"
LS="/bin/ls"

LOG="$HOME/Desktop/bezier_inspector_diagnostics_$($DATE +%Y%m%d_%H%M%S).log"
exec > >($TEE -a "$LOG") 2>&1

EXT="$HOME/Library/Application Support/Adobe/CEP/extensions/com.ju.bezierinspector"

echo "Bézier Inspector diagnostics"
echo "Log: $LOG"
echo ""

echo "System:"
if [ -x "$SW_VERS" ]; then "$SW_VERS"; else "$UNAME" -a; fi

echo ""
echo "Shell PATH:"
echo "$PATH"

echo ""
echo "defaults command:"
if [ -x "$DEFAULTS" ]; then
  echo "$DEFAULTS exists"
else
  echo "WARNING: /usr/bin/defaults not found. Are you on macOS?"
fi

echo ""
echo "PlayerDebugMode:"
if [ -x "$DEFAULTS" ]; then
  "$DEFAULTS" read com.adobe.CSXS.11 PlayerDebugMode 2>&1 || true
  "$DEFAULTS" read com.adobe.CSXS.12 PlayerDebugMode 2>&1 || true
  "$DEFAULTS" read com.adobe.CSXS.13 PlayerDebugMode 2>&1 || true
else
  echo "Skipped: defaults command unavailable."
fi

echo ""
echo "Installed extension folder:"
if [ -d "$EXT" ]; then
  "$FIND" "$EXT" -maxdepth 3 -print | sort
  echo ""
  echo "Quarantine attributes:"
  "$XATTR" -lr "$EXT" 2>/dev/null | "$GREP" -i quarantine || echo "No quarantine attribute found."
  echo ""
  echo "Permissions:"
  "$LS" -la "$EXT"
else
  echo "Not found: $EXT"
fi

echo ""
echo "Duplicate folder check:"
"$FIND" "$HOME/Library/Application Support/Adobe/CEP/extensions" \
  "/Library/Application Support/Adobe/CEP/extensions" \
  -maxdepth 3 -iname "*bezier*" -print 2>/dev/null || true

echo ""
echo "Recent CEP/CSXS logs:"
"$FIND" "$HOME/Library/Logs/CEP" "$HOME/Library/Logs/CSXS" -maxdepth 2 -type f -mtime -7 -print 2>/dev/null || true

echo ""
echo "Diagnostics complete. Send this log if troubleshooting is needed."
