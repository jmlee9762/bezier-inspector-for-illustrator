#!/bin/bash
set -euo pipefail

export PATH="/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin:/usr/local/bin:${PATH:-}"

if [ "$(/usr/bin/uname -s 2>/dev/null || uname -s)" != "Darwin" ]; then
  echo "ERROR: This repair script is for macOS only."
  echo "The 'defaults' command exists only on macOS."
  exit 1
fi

DEFAULTS="/usr/bin/defaults"
PGREP="/usr/bin/pgrep"
XATTR="/usr/bin/xattr"
CHMOD="/bin/chmod"
RM="/bin/rm"
FIND="/usr/bin/find"
DATE="/bin/date"
TEE="/usr/bin/tee"

if [ ! -x "$DEFAULTS" ]; then
  echo "ERROR: macOS defaults command was not found at /usr/bin/defaults."
  echo "Please run this script in the built-in macOS Terminal app."
  exit 1
fi

EXT="$HOME/Library/Application Support/Adobe/CEP/extensions/com.ju.bezierinspector"
LOG="$HOME/Desktop/bezier_inspector_repair_$($DATE +%Y%m%d_%H%M%S).log"
exec > >($TEE -a "$LOG") 2>&1

echo "Bézier Inspector gray-panel repair"
echo "Log: $LOG"
echo ""

if "$PGREP" -x "Adobe Illustrator" >/dev/null 2>&1; then
  echo "ERROR: Please quit Adobe Illustrator before repair."
  exit 1
fi

echo "Enabling CEP PlayerDebugMode."
"$DEFAULTS" write com.adobe.CSXS.11 PlayerDebugMode 1
"$DEFAULTS" write com.adobe.CSXS.12 PlayerDebugMode 1
"$DEFAULTS" write com.adobe.CSXS.13 PlayerDebugMode 1

if [ -d "$EXT" ]; then
  echo "Removing quarantine and fixing permissions: $EXT"
  "$XATTR" -dr com.apple.quarantine "$EXT" 2>/dev/null || true
  "$CHMOD" -R u+rwX "$EXT" 2>/dev/null || true
else
  echo "WARNING: Installed extension folder not found: $EXT"
fi

echo "Clearing CEP cache."
"$RM" -rf "$HOME/Library/Caches/CSXS/cep_cache" 2>/dev/null || true
"$RM" -rf "$HOME/Library/Caches/CSXS/cep_cache_*" 2>/dev/null || true

echo ""
echo "Duplicate folder check:"
"$FIND" "$HOME/Library/Application Support/Adobe/CEP/extensions" \
  "/Library/Application Support/Adobe/CEP/extensions" \
  -maxdepth 3 -iname "*bezier*" -print 2>/dev/null || true

echo ""
echo "Repair complete. Restart Illustrator."
