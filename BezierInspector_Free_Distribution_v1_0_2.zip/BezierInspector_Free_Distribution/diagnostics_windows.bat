@echo off
setlocal EnableExtensions

set "OUT=%USERPROFILE%\Desktop\BezierInspector_Diagnostics_Windows.txt"
set "TARGET_ROOT=%APPDATA%\Adobe\CEP\extensions"
set "TARGET_DIR=%TARGET_ROOT%\com.ju.bezierinspector"

echo Writing diagnostics to:
echo %OUT%
echo.

> "%OUT%" echo Bezier Inspector Diagnostics - Windows
>> "%OUT%" echo ======================================
>> "%OUT%" echo Date: %DATE% %TIME%
>> "%OUT%" echo User: %USERNAME%
>> "%OUT%" echo COMPUTERNAME: %COMPUTERNAME%
>> "%OUT%" echo APPDATA: %APPDATA%
>> "%OUT%" echo LOCALAPPDATA: %LOCALAPPDATA%
>> "%OUT%" echo.
>> "%OUT%" echo [Windows Version]
ver >> "%OUT%"
>> "%OUT%" echo.
>> "%OUT%" echo [Extension Target]
>> "%OUT%" echo %TARGET_DIR%
>> "%OUT%" echo.
>> "%OUT%" echo [Installed Extension Tree]
if exist "%TARGET_DIR%" (
  dir /s /b "%TARGET_DIR%" >> "%OUT%"
) else (
  >> "%OUT%" echo NOT FOUND
)
>> "%OUT%" echo.
>> "%OUT%" echo [Possible Duplicate Folders]
if exist "%TARGET_ROOT%" (
  dir /s /b "%TARGET_ROOT%" 2>nul | findstr /I "bezier" >> "%OUT%"
) else (
  >> "%OUT%" echo CEP extensions folder not found.
)
>> "%OUT%" echo.
>> "%OUT%" echo [PlayerDebugMode Registry]
for %%V in (8 9 10 11 12 13) do (
  >> "%OUT%" echo --- CSXS.%%V ---
  reg query "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode >> "%OUT%" 2>&1
)
>> "%OUT%" echo.
>> "%OUT%" echo [Illustrator Process]
tasklist /FI "IMAGENAME eq Illustrator.exe" >> "%OUT%" 2>&1

echo Done.
echo %OUT%
echo.
pause
exit /b 0
