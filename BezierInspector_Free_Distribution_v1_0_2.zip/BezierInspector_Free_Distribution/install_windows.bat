@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "EXT_ID=com.ju.bezierinspector"
set "SCRIPT_DIR=%~dp0"
set "SRC_DIR=%SCRIPT_DIR%%EXT_ID%"
set "TARGET_ROOT=%APPDATA%\Adobe\CEP\extensions"
set "TARGET_DIR=%TARGET_ROOT%\%EXT_ID%"
set "CACHE_DIR=%LOCALAPPDATA%\Adobe\CEP\cep_cache"

echo.
echo ================================================
echo  Bezier Inspector Windows Installer
echo  Bezier Inspector Windows Install Script
echo ================================================
echo.

net session >nul 2>&1
if "%ERRORLEVEL%"=="0" (
  echo Do not run this installer as Administrator.
  echo Run it as the normal Windows user who uses Illustrator.
  echo.
  pause
  exit /b 1
)

tasklist /FI "IMAGENAME eq Illustrator.exe" 2>nul | find /I "Illustrator.exe" >nul
if "%ERRORLEVEL%"=="0" (
  echo Adobe Illustrator is running.
  echo Please quit Illustrator completely, then run this installer again.
  echo.
  pause
  exit /b 1
)

if not exist "%SRC_DIR%\CSXS\manifest.xml" (
  echo ERROR: Could not find extension source folder:
  echo %SRC_DIR%
  echo.
  echo Make sure this .bat file is in the same folder as "%EXT_ID%".
  echo.
  pause
  exit /b 1
)

echo Creating CEP extensions folder...
if not exist "%TARGET_ROOT%" mkdir "%TARGET_ROOT%"

echo Removing old duplicate installs...
if exist "%TARGET_ROOT%\com.ju.bezierInspector" rmdir /S /Q "%TARGET_ROOT%\com.ju.bezierInspector"
if exist "%TARGET_ROOT%\Bezier Inspector" rmdir /S /Q "%TARGET_ROOT%\Bezier Inspector"
if exist "%TARGET_DIR%" rmdir /S /Q "%TARGET_DIR%"

echo Copying extension...
robocopy "%SRC_DIR%" "%TARGET_DIR%" /E /NFL /NDL /NJH /NJS /NP >nul
set "RC=%ERRORLEVEL%"
if %RC% GEQ 8 (
  echo ERROR: Copy failed. Robocopy error code: %RC%
  echo.
  pause
  exit /b 1
)

echo Enabling CEP PlayerDebugMode...
for %%V in (8 9 10 11 12 13) do (
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
)

echo Clearing CEP cache...
if exist "%CACHE_DIR%" rmdir /S /Q "%CACHE_DIR%"
if exist "%LOCALAPPDATA%\Temp\CEPHtmlEngine" rmdir /S /Q "%LOCALAPPDATA%\Temp\CEPHtmlEngine" 2>nul

echo.
echo ================================================
echo  Installed successfully.
echo ================================================
echo.
echo Restart Adobe Illustrator, then open:
echo.
echo  Illustrator 2022:
echo  Window ^> Extensions ^> Bezier Inspector
echo.
echo  Illustrator 2023-2026:
echo  Window ^> Extensions (Legacy) ^> Bezier Inspector
echo.
echo  Korean UI:
echo  Window/Chang ^> Extensions or Extensions (Legacy) ^> Bezier Inspector
echo.
pause
exit /b 0
