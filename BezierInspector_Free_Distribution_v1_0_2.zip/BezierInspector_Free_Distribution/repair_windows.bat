@echo off
setlocal EnableExtensions

set "EXT_ID=com.ju.bezierinspector"
set "TARGET_ROOT=%APPDATA%\Adobe\CEP\extensions"
set "TARGET_DIR=%TARGET_ROOT%\%EXT_ID%"
set "CACHE_DIR=%LOCALAPPDATA%\Adobe\CEP\cep_cache"

echo.
echo ================================================
echo  Bezier Inspector Gray Panel Repair - Windows
echo ================================================
echo.

if not exist "%TARGET_DIR%\CSXS\manifest.xml" (
  echo WARNING: Extension folder was not found at:
  echo %TARGET_DIR%
  echo.
  echo Please run install_windows.bat first.
  echo.
  pause
  exit /b 1
)

echo Enabling CEP PlayerDebugMode...
for %%V in (8 9 10 11 12 13) do (
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
)

echo Clearing CEP cache...
if exist "%CACHE_DIR%" rmdir /S /Q "%CACHE_DIR%"
if exist "%LOCALAPPDATA%\Temp\CEPHtmlEngine" rmdir /S /Q "%LOCALAPPDATA%\Temp\CEPHtmlEngine" 2>nul

echo Checking possible duplicate folders...
dir /s /b "%TARGET_ROOT%" 2>nul | findstr /I "bezier"

echo.
echo Repair complete. Restart Illustrator.
echo.
pause
exit /b 0
